from setuptools import setup

setup(name='Hello',
    version='1.0',
    description='A simple example',
    author='Lin Feng',
    py_modules=['hello'])